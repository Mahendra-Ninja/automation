# flask_todo_app
A todo app having CRUD functionalities and Search Operation.

https://github.com/iamnandini/flask_todo_app/assets/117187906/77430559-668c-468d-8472-4d9e3b3d5e20

